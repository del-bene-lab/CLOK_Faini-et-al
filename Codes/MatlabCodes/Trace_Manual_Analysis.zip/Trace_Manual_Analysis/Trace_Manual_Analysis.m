
% This code first load the structure summ.EARLY  and summ.late containing the
% df/f traces , toeghether with some properties resutl of the first
% automatic screening (see code in WhaloCamp_traceClusteringANDselection_essential.zip )

% Then usign the GUI in the  function manualVerifyTraces , trace properties
% can be manually validate and adjsuted. 

% an overvie is the plot 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


load('summ.mat');   


%% --------  Manual verification (clean + no duplicates) --------

summadj = summ; % default: no manual changes

if exist('manualVerifyTraces','file') == 2
    % Uncomment whichever you want to verify:
     summadj = manualVerifyTraces(summadj,'LATE');
    % summadj = manualVerifyTraces(summadj,'EARLY');
end

% choose which struct to plot
summTOplot = summadj;

%% -------- 4) Group-wise Summary Plots (essential, robust) --------
params  = {'freqPEAK', 'meanPEAK', 'integralFIT'};
titles  = {'Peak Frequency', 'Mean Peak Amplitude', 'Integral (Fitted Ca)'};
ylabels = {'peaks/frame', 'Amplitude (a.u.)', 'Integral (a.u.)'};

early_color = [0 0.8 0.8];  % cyan
late_color  = [1 0 1];      % magenta

% Active masks (force logical + handle numeric)
early_active = logical(summTOplot.EARLY.STATUS(:));
late_active  = logical(summTOplot.LATE.STATUS(:));

ratio_early = nnz(early_active) / max(1, numel(early_active));
ratio_late  = nnz(late_active)  / max(1, numel(late_active));

figure('Name','Group Comparison: EARLY vs LATE','Position',[100 200 1500 600]); clf;

% Ratios of active cells
subplot(2, numel(params)+1, 1); hold on;
bar(1, ratio_early, 0.6, 'FaceColor', early_color, 'EdgeColor', 'none');
bar(2, ratio_late,  0.6, 'FaceColor', late_color,  'EdgeColor', 'none');
set(gca, 'XTick', [1 2], 'XTickLabel', {'EARLY','LATE'});
ylabel('Active / total'); title('Active cell ratio');
ylim([0 1]); grid on; box off;

for p = 1:numel(params)
    param = params{p};

    % pull values (as columns)
    early_all = summTOplot.EARLY.(param); early_all = early_all(:);
    late_all  = summTOplot.LATE.(param);  late_all  = late_all(:);

    % keep only active + finite
    early_values = early_all(early_active);
    late_values  = late_all(late_active);

    early_values = early_values(isfinite(early_values));
    late_values  = late_values(isfinite(late_values));

    % ---------- Boxplot (top row) ----------
    subplot(2, numel(params)+1, 1+p); hold on;
    data   = [early_values; late_values];
    groups = [ones(size(early_values)); 2*ones(size(late_values))];

    if isempty(data)
        text(0.5,0.5,'No data','HorizontalAlignment','center'); axis off;
        continue;
    end

    boxplot(data, groups, 'Labels', {'EARLY','LATE'}, 'Symbol','');
    title(titles{p}); ylabel(ylabels{p}); grid on; box off;

    % color the boxes robustly (order is not guaranteed, so use X positions)
    hBox = findobj(gca,'Tag','Box');
    for hb = 1:numel(hBox)
        xd = get(hBox(hb),'XData');
        xcenter = mean(xd);
        if abs(xcenter-1) < 0.2
            patch(xd, get(hBox(hb),'YData'), early_color, 'FaceAlpha',0.35, 'EdgeColor','none');
        elseif abs(xcenter-2) < 0.2
            patch(xd, get(hBox(hb),'YData'), late_color, 'FaceAlpha',0.35, 'EdgeColor','none');
        end
    end

    % stats (ttest2) if both groups have enough data
    pval = NaN;
    if numel(early_values) >= 2 && numel(late_values) >= 2
        [~, pval] = ttest2(early_values, late_values);
    end
    if isfinite(pval) && pval < 0.05
        y_star = max(data) * 1.08;
        text(1.5, y_star, sprintf('* (p=%.3g)', pval), ...
            'Color','r','HorizontalAlignment','center','FontSize',11);
    end

    % ---------- Mean ± SEM (bottom row) ----------
    subplot(2, numel(params)+1, (numel(params)+1) + 1 + p); hold on;

    means = [mean(early_values,'omitnan'), mean(late_values,'omitnan')];
    sems  = [std(early_values,'omitnan')/max(1,sqrt(numel(early_values))), ...
             std(late_values,'omitnan') /max(1,sqrt(numel(late_values)))];

    bar(1, means(1), 0.6, 'FaceColor', early_color, 'EdgeColor','none');
    bar(2, means(2), 0.6, 'FaceColor', late_color,  'EdgeColor','none');
    errorbar(1:2, means, sems, 'k', 'LineStyle','none', 'LineWidth',1.2);

    set(gca,'XTick',[1 2],'XTickLabel',{'EARLY','LATE'});
    ylabel('Mean ± SEM'); grid on; box off;
end

sgtitle('EARLY (cyan) vs LATE (magenta) — Active cells only');