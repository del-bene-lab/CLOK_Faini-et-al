function summ = manualVerifySumm(summ, groupName)
% MANUALVERIFYSUMM  GUI to manually inspect and edit STATUS and peaks using struct summ.
%
%   summ = manualVerifySumm(summ)
%   summ = manualVerifySumm(summ, 'EARLY')
%   summ = manualVerifySumm(summ, 'LATE')
%
%   Uses struct 'summ' with fields per group G:
%       summ.(G).traceRAW{idx}    - raw DF/F trace (row or vector)
%       summ.(G).traceDEC{idx}    - deconvolved trace (optional)
%       summ.(G).baseline(idx)    - baseline value
%       summ.(G).STATUS(idx)      - original automatic status (0/1)
%       summ.(G).MAN.STATUS(idx)  - manual status (if already edited)
%
%       summ.(G).PEAKS_loc{idx}   - peak x positions (frames), ABSOLUTE
%       summ.(G).PEAKS_amp{idx}   - peak y amplitudes (absolute DF/F)
%       summ.(G).ALLpeaks{idx}    - peak amplitudes ABOVE BASELINE:
%                                   ALLpeaks{idx} = PEAKS_amp{idx} - baseline(idx)
%       summ.(G).totTime(idx)     - duration (for freqPEAK recomputation)
%       summ.(G).freqPEAK(idx)    - peak frequency (updated here)
%       summ.(G).meanPEAK(idx)    - mean peak amplitude above baseline (updated here)
%
%   GUI features:
%       - Shows one trace at a time (raw, deconv, baseline, peaks).
%       - Grey plotting if STATUS == 0.
%       - Left / Right buttons to move between traces.
%       - "Toggle STATUS" button to flip STATUS for current trace.
%       - Peaks shown as scatter dots using PEAKS_loc / PEAKS_amp.
%       - LEFT CLICK: add a peak at clicked (x,y).
%           -> stored as PEAKS_loc{idx} = x, PEAKS_amp{idx} = y
%           -> ALLpeaks{idx} = PEAKS_amp{idx} - baseline(idx)
%           -> freqPEAK & meanPEAK updated.
%       - RIGHT CLICK: if x-click is within 10 frames of an existing peak,
%           remove that peak and update PEAKS_loc, PEAKS_amp, ALLpeaks,
%           freqPEAK and meanPEAK.
%       - "Save summ..." button: opens file-save dialog and saves current 'summ'.
%
%   The function waits until the GUI is closed (uiwait), then returns updated 'summ'.

    %% ---- basic checks ----
    if nargin < 1 || isempty(summ)
        error('Input struct ''summ'' is required.');
    end

    %% ---- choose group name ----
    if nargin < 2 || isempty(groupName)
        if isfield(summ, 'EARLY')
            groupName = 'EARLY';
        else
            fns = fieldnames(summ);
            if isempty(fns)
                error('The struct ''summ'' has no fields.');
            end
            groupName = fns{1};
        end
    end

    if ~isfield(summ, groupName)
        error('Group "%s" not found in summ.', groupName);
    end

    G = groupName;  % shorthand

    %% ---- get number of traces ----
    if ~isfield(summ.(G), 'traceRAW') || isempty(summ.(G).traceRAW)
        error('summ.%s.traceRAW is missing or empty.', G);
    end

    nTraces = numel(summ.(G).traceRAW);

    %% ---- STATUS: use MAN.STATUS if exists, else STATUS, else ones ----
    if isfield(summ.(G), 'MAN') && isfield(summ.(G).MAN, 'STATUS') && ~isempty(summ.(G).MAN.STATUS)
        STATUS = summ.(G).MAN.STATUS(:)';
    elseif isfield(summ.(G), 'STATUS') && ~isempty(summ.(G).STATUS)
        STATUS = summ.(G).STATUS(:)';
    else
        STATUS = ones(1, nTraces);
    end
    if numel(STATUS) < nTraces
        STATUS(numel(STATUS)+1:nTraces) = STATUS(end);
    end

    %% ---- BASELINE (for ALLpeaks) ----
    if isfield(summ.(G), 'baseline') && ~isempty(summ.(G).baseline)
        BASELINE = summ.(G).baseline(:)';
    else
        BASELINE = zeros(1, nTraces); % fallback
    end
    if numel(BASELINE) < nTraces
        BASELINE(numel(BASELINE)+1:nTraces) = BASELINE(end);
    end

    %% ---- peaks: positions + absolute amplitudes ----
    % positions
    if isfield(summ.(G), 'PEAKS_loc') && ~isempty(summ.(G).PEAKS_loc)
        PEAKS_loc = summ.(G).PEAKS_loc;
    else
        PEAKS_loc = cell(nTraces,1);
    end

    % absolute amplitudes
    if isfield(summ.(G), 'PEAKS_amp') && ~isempty(summ.(G).PEAKS_amp)
        PEAKS_amp = summ.(G).PEAKS_amp;
    else
        % if only ALLpeaks (above baseline) exists, reconstruct absolute amps
        PEAKS_amp = cell(nTraces,1);
        if isfield(summ.(G), 'ALLpeaks') && ~isempty(summ.(G).ALLpeaks)
            allp = summ.(G).ALLpeaks;
            for ii = 1:min(numel(allp), nTraces)
                if ~isempty(allp{ii})
                    PEAKS_amp{ii} = allp{ii}(:) + BASELINE(ii);
                else
                    PEAKS_amp{ii} = [];
                end
            end
        end
    end

    % ensure local cell arrays are long enough
    if numel(PEAKS_loc) < nTraces, PEAKS_loc{nTraces} = []; end
    if numel(PEAKS_amp) < nTraces, PEAKS_amp{nTraces} = []; end

    %% ---- name for the plot title ----
    varName = 'traceRAW';

    %% ---- build GUI ----
    hFig = figure('Name', sprintf('Manual verification: %s (%s)', varName, G), ...
                  'NumberTitle', 'off', ...
                  'Units','normalized', ...
                  'Position',[0.2 0.15 0.6 0.7], ...
                  'CloseRequestFcn', @onClose, ...
                  'WindowButtonDownFcn', @onMouseClick);

    hAx = axes('Parent', hFig, ...
               'Units','normalized', ...
               'Position',[0.1 0.25 0.85 0.7]);
    hold(hAx, 'on');

    hTxt = uicontrol('Style','text', ...
                     'Parent', hFig, ...
                     'Units','normalized', ...
                     'Position',[0.1 0.05 0.8 0.05], ...
                     'HorizontalAlignment','left', ...
                     'String','');

    hBtnPrev = uicontrol('Style','pushbutton', ...
                         'Parent', hFig, ...
                         'Units','normalized', ...
                         'Position',[0.05 0.15 0.1 0.06], ...
                         'String','<< Prev', ...
                         'Callback', @onPrev);

    hBtnNext = uicontrol('Style','pushbutton', ...
                         'Parent', hFig, ...
                         'Units','normalized', ...
                         'Position',[0.85 0.15 0.1 0.06], ...
                         'String','Next >>', ...
                         'Callback', @onNext);

    hBtnToggle = uicontrol('Style','pushbutton', ...
                           'Parent', hFig, ...
                           'Units','normalized', ...
                           'Position',[0.30 0.15 0.18 0.06], ...
                           'String','Toggle STATUS', ...
                           'Callback', @onToggleStatus);

    hBtnSave = uicontrol('Style','pushbutton', ...
                         'Parent', hFig, ...
                         'Units','normalized', ...
                         'Position',[0.52 0.15 0.18 0.06], ...
                         'String','Save summ...', ...
                         'Callback', @onSaveSumm);

    % current index
    idx = 1;

    % threshold for removing peaks (in x data units, i.e. frames)
    xRemoveThreshold = 10;

    updatePlot();

    % wait until user closes the figure, then return updated summ
    uiwait(hFig);

    %% ========== nested functions ==========

    function updatePlot()
        cla(hAx);
        hold(hAx, 'on');

        % ---- get current trace ----
        traceRAW = summ.(G).traceRAW{idx};
        traceRAW = traceRAW(:)';     % row
        T = numel(traceRAW);
        t = 1:T;

        % ---- STATUS ----
        statusVal = STATUS(idx);
        isActive  = statusVal ~= 0;

        % ---- colors depending on STATUS (grey if inactive) ----
        if isActive
            colRaw   = [0 0 1];      % blue
            colDec   = [1 0 0];      % red
            colBase  = [0 0.6 0];    % green
            colPeak  = [0 0 0];      % black
        else
            colRaw   = [0.6 0.6 0.6];
            colDec   = [0.5 0.5 0.5];
            colBase  = [0.7 0.7 0.7];
            colPeak  = [0.3 0.3 0.3];
        end

        % ---- raw trace ----
        plot(hAx, t, traceRAW, ...
             'Color', colRaw, ...
             'DisplayName','raw');

        % ---- deconvolved trace if exists ----
        if isfield(summ.(G), 'traceDEC') && ...
           numel(summ.(G).traceDEC) >= idx && ...
           ~isempty(summ.(G).traceDEC{idx})

            c = summ.(G).traceDEC{idx};
            c = c(:)';
            if numel(c) == T
                plot(hAx, t, c, ...
                     'Color', colDec, ...
                     'LineWidth', 1.5, ...
                     'DisplayName','deconv c');
            else
                plot(hAx, c, ...
                     'Color', colDec, ...
                     'LineWidth', 1.5, ...
                     'DisplayName','deconv c');
            end
        end

        % ---- baseline ----
        base = BASELINE(idx);
        yline(hAx, base, '--', ...
              'Color', colBase, ...
              'DisplayName','baseline');

        % ---- peaks (scatter dots, using absolute amplitude) ----
        locs    = PEAKS_loc{idx};
        ampsAbs = PEAKS_amp{idx};
        if ~isempty(locs) && ~isempty(ampsAbs)
            locs    = locs(:);
            ampsAbs = ampsAbs(:);
            nMin = min(numel(locs), numel(ampsAbs));
            scatter(hAx, locs(1:nMin), ampsAbs(1:nMin), ...
                    40, colPeak, 'filled', ...
                    'DisplayName','peaks');
        end

        % ---- formatting similar to VIS block ----
        grid(hAx, 'on');
        xlabel(hAx, 'Frame');
        ylabel(hAx, 'DF/F');
        ylim(hAx, [-0.02 0.2]);
        xlim(hAx, [1 T]);

        title(hAx, sprintf('%s (%s)  ROI #%d  |  STATUS = %d', ...
                           varName, G, idx, statusVal));

        set(hTxt, 'String', ...
            sprintf('%s | trace %d / %d | STATUS = %d', ...
                    G, idx, nTraces, statusVal));

        hold(hAx, 'off');
    end

    function onPrev(~, ~)
        if idx > 1
            idx = idx - 1;
            updatePlot();
        end
    end

    function onNext(~, ~)
        if idx < nTraces
            idx = idx + 1;
            updatePlot();
        end
    end

    function onToggleStatus(~, ~)
        % flip STATUS
        STATUS(idx) = ~logical(STATUS(idx));

        % ensure MAN struct exists
        if ~isfield(summ.(G), 'MAN') || ~isstruct(summ.(G).MAN)
            summ.(G).MAN = struct();
        end

        % store new status
        summ.(G).MAN.STATUS(idx) = STATUS(idx);
        summ.(G).STATUS(idx) = STATUS(idx);

        % refresh
        updatePlot();
    end

    function updatePeakDerivedMetrics()
        % Helper: update ALLpeaks, freqPEAK, meanPEAK for current idx
        base = BASELINE(idx);
        ampsAbs = PEAKS_amp{idx};
        if isempty(ampsAbs)
            relAmp = [];
        else
            relAmp = ampsAbs(:) - base;
        end

        % ALLpeaks = amplitudes above baseline
        if ~isfield(summ.(G), 'ALLpeaks') || numel(summ.(G).ALLpeaks) < idx
            summ.(G).ALLpeaks{idx} = relAmp;
        else
            summ.(G).ALLpeaks{idx} = relAmp;
        end

        % freqPEAK & meanPEAK if totTime exists
        if isfield(summ.(G), 'totTime') && numel(summ.(G).totTime) >= idx && ~isempty(summ.(G).totTime(idx))
            if isempty(relAmp)
                summ.(G).freqPEAK(idx) = 0;
                summ.(G).meanPEAK(idx) = NaN;
            else
                summ.(G).freqPEAK(idx) = numel(relAmp) / summ.(G).totTime(idx);
                summ.(G).meanPEAK(idx) = mean(relAmp);
            end
        end
    end

    function onMouseClick(~, ~)
        % handle left/right clicks on the axes for peak editing
        if isempty(hFig) || ~ishghandle(hFig)
            return;
        end

        selType = get(hFig, 'SelectionType');   % 'normal' (left), 'alt' (right)

        % current point in axes coordinates
        cp = get(hAx, 'CurrentPoint');
        xClick = cp(1,1);
        yClick = cp(1,2);

        % only act if click is inside axes limits
        xl = xlim(hAx);
        yl = ylim(hAx);
        if xClick < xl(1) || xClick > xl(2) || yClick < yl(1) || yClick > yl(2)
            return;
        end

        switch selType
            case 'normal'   % LEFT click -> ADD a peak
                newX    = round(xClick);
                newYabs = yClick;

                if isempty(PEAKS_loc{idx})
                    PEAKS_loc{idx} = newX;
                    PEAKS_amp{idx} = newYabs;
                else
                    PEAKS_loc{idx} = [PEAKS_loc{idx}(:); newX];
                    PEAKS_amp{idx} = [PEAKS_amp{idx}(:); newYabs];
                end

                % sort peaks by x
                [PEAKS_loc{idx}, sortIdx] = sort(PEAKS_loc{idx});
                PEAKS_amp{idx} = PEAKS_amp{idx}(sortIdx);

                % write back into summ and update derived metrics
                summ.(G).PEAKS_loc = PEAKS_loc;
                summ.(G).PEAKS_amp = PEAKS_amp;
                updatePeakDerivedMetrics();

                updatePlot();

            case 'alt'      % RIGHT click -> REMOVE nearest peak (if close)
                locs    = PEAKS_loc{idx};
                ampsAbs = PEAKS_amp{idx};

                if isempty(locs) || isempty(ampsAbs)
                    return;
                end

                locs    = locs(:);
                ampsAbs = ampsAbs(:);

                [minDist, iMin] = min(abs(locs - xClick));

                if minDist <= xRemoveThreshold
                    locs(iMin)    = [];
                    ampsAbs(iMin) = [];

                    PEAKS_loc{idx} = locs;
                    PEAKS_amp{idx} = ampsAbs;

                    % write back & update derived metrics
                    summ.(G).PEAKS_loc = PEAKS_loc;
                    summ.(G).PEAKS_amp = PEAKS_amp;
                    updatePeakDerivedMetrics();

                    updatePlot();
                end

            otherwise
                % ignore other click types
        end
    end

    function onSaveSumm(~, ~)
        [fileName, pathName] = uiputfile('summ_manual.mat', 'Save summ as');
        if isequal(fileName,0) || isequal(pathName,0)
            return; % user cancelled
        end
        fullName = fullfile(pathName, fileName);
        s = summ; %#ok<NASGU>
        save(fullName, 's');   % or save(fullName,'summ') if you prefer
    end

    function onClose(~, ~)
        if ishghandle(hFig)
            uiresume(hFig);
            delete(hFig);
        end
    end

end
