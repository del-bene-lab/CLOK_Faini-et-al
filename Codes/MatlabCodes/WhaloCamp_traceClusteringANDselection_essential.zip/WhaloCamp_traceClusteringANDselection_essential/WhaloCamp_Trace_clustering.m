
load Traces_and_Essentialvariables

%% ROI cross-channel pairing + metric + clustering + selection (ESSENTIAL VERSION)
% This script:
% 1) pairs ROIs between 561 and 642 channels by nearest-neighbor distance,
% 2) computes a per-pair metric (ratio or ratioVector),
% 3) clusters pairs using k-means or GMM (keeps only 2 clusters for simplicity),
% 4) extracts traces from LOW-metric (642) and HIGH-metric (561) clusters,
% 5) normalizes traces (requires external helper functions),
% 6) selects "active" traces using a peak/SNR criterion (requires helper function),
% 7) plots summaries.
%
% -----------------------
% ESSENTIAL INPUT VARIABLES (must exist in workspace)
% -----------------------
% x561, y561 : ROI centroid coordinates in the 561 image (vectors, n561 x 1)
% x642, y642 : ROI centroid coordinates in the 642 image (vectors, n642 x 1)
% traces561  : fluorescence traces for 561 channel (n561 x T)
% traces642  : fluorescence traces for 642 channel (n642 x T)
% img561     : 2D image for display (561 channel)
% img642     : 2D image for display (642 channel)
%
% -----------------------
% REQUIRED FUNCTIONS ON PATH (not workspace variables)
% -----------------------
% detrend_and_smooth(traces, poly_degree, smoothCoeff)
% normalize_traces(traces, method, baseline_percentile)
% filter_traces_by_peak(traces, abs_threshold, snr_threshold)

%% ---------------------------
% PARAMETERS (keep only essential ones)
% ---------------------------
pair_thr  = 6;          % max distance (px) to consider a 561 ROI matched to a 642 ROI
eps_denom = 1e-12;      % avoid divide-by-zero
METRIC    = 'ratio';    % 'ratio' or 'ratioVector'

CLUST_METHOD = 'gmm';   % 'kmeans' or 'gmm'
Kmin = 2; Kmax = 4;     % range for automatic model order selection

% preprocessing/selection
DETREND     = true;
SMOOTHcoeff = 4;
poly_degree = 1;
method      = 'dff';    % 'dff' or 'zscore'
baseline_percentile = 10;

absolute_peak_threshold = 0.05;
SNRthreshold            = 2;

%% ---------------------------
% QUICK INPUT CHECKS (essential)
% ---------------------------
req = {'x561','y561','x642','y642','traces561','traces642','img561','img642'};
missing = setdiff(req, who);
if ~isempty(missing)
    error('Missing required variables: %s', strjoin(missing, ', '));
end
assert(size(traces561,1)==numel(x561) && size(traces561,1)==numel(y561), 'traces561 must be n561 x T with n561=numel(x561)=numel(y561).');
assert(size(traces642,1)==numel(x642) && size(traces642,1)==numel(y642), 'traces642 must be n642 x T with n642=numel(x642)=numel(y642).');

%% ---------------------------
% 1) PAIR ROIs (greedy nearest neighbor, no duplicates)
% ---------------------------
n1 = numel(x561); 
n2 = numel(x642);

DX = x561(:) - x642(:)';  
DY = y561(:) - y642(:)';
Dist = hypot(DX, DY);                 % n1 x n2

pairs = zeros(0,2);
used1 = false(n1,1); 
used2 = false(n2,1);

while true
    DistMasked = Dist;
    DistMasked(used1,:) = inf;
    DistMasked(:,used2) = inf;

    [mn, idx] = min(DistMasked(:));
    if ~isfinite(mn) || mn > pair_thr
        break;
    end
    [i1, i2] = ind2sub([n1 n2], idx);
    pairs(end+1,:) = [i1 i2]; %#ok<SAGROW>
    used1(i1) = true; 
    used2(i2) = true;
end

if isempty(pairs)
    warning('No ROI pairs found within pair_thr=%.2f px. Stopping.', pair_thr);
    return;
end

i561 = pairs(:,1);
i642 = pairs(:,2);

%% ---------------------------
% 2) COMPUTE METRIC PER PAIR
% ---------------------------
F561 = mean(traces561, 2);
F642 = mean(traces642, 2);

fluo561 = F561(i561);
fluo642 = F642(i642);

switch lower(METRIC)
    case 'ratio'
        Xraw  = fluo561 ./ max(fluo561 + fluo642, eps_denom); % [0..1]
        Xnorm = min(max(Xraw,0),1);                            % for coloring
        xLabel = 'RATIO = 561 / (561 + 642)';
    case 'ratiovector'
        Xraw  = atan2(fluo561, max(fluo642, eps_denom));       % [0..pi/2]
        Xnorm = Xraw / (pi/2);                                 % [0..1]
        xLabel = 'RATIOVECTOR = atan(561/642) [rad]';
    otherwise
        error('Unknown METRIC "%s". Use ''ratio'' or ''ratioVector''.', METRIC);
end

[~, order] = sort(Xraw, 'ascend');
i561_ord = i561(order);
i642_ord = i642(order);

%% ---------------------------
% 3) PLOT: ROI MAP + ORDERED RASTERS (essential)
% ---------------------------
% purple->cyan colormap for the metric
nC = 256;
c1 = [0.5 0.00 0.5];
c2 = [0.0 1.00 1.0];
cmap = [linspace(c1(1),c2(1),nC)', linspace(c1(2),c2(2),nC)', linspace(c1(3),c2(3),nC)'];
ci = max(1, min(nC, round(1 + Xnorm*(nC-1))));

figure('Name','ROI Metric & Ordered Rasters','Position',[100 100 1600 520]);

subplot(1,3,1);
imshow(img561, [], 'InitialMagnification','fit'); hold on;
scatter(x561(i561), y561(i561), 45, cmap(ci,:), 'filled', 'MarkerEdgeColor','k','LineWidth',0.5);
title(sprintf('ROIs colored by %s', METRIC));
colormap(gca, cmap);
caxis([0 1]);
cb = colorbar; 
cb.Label.String = sprintf('%s (normalized 0..1)', METRIC);
hold off;

subplot(1,3,2);
imagesc(traces561(i561_ord,:));
xlabel('Time (frames)'); ylabel(sprintf('ROI (low \\rightarrow high %s)', METRIC));
title('561 traces (ordered)');
colormap(gca, hot); colorbar;
caxis([0 prctile(traces561(i561_ord,:), 99.5, 'all')]);

subplot(1,3,3);
imagesc(traces642(i642_ord,:));
xlabel('Time (frames)'); ylabel(sprintf('ROI (low \\rightarrow high %s)', METRIC));
title('642 traces (ordered)');
colormap(gca, hot); colorbar;
caxis([0 prctile(traces642(i642_ord,:), 99.5, 'all')]);

sgtitle(sprintf('Paired ROIs (N=%d), thr=%.1f px, METRIC=%s', numel(Xraw), pair_thr, METRIC));

%% ---------------------------
% 4) CLUSTER METRIC (auto K, then FORCE to 2 clusters for downstream)
% ---------------------------
X = Xraw(:);
N = numel(X);

switch lower(CLUST_METHOD)
    case 'kmeans'
        bestSil = -inf; bestIdx = [];
        opts = statset('MaxIter', 1000, 'Display', 'off');
        for K = Kmin:min(Kmax, N)
            try
                idx0 = kmeans(X, K, 'Replicates', 10, 'Options', opts, 'Distance','sqeuclidean');
                sil = mean(silhouette(X, idx0), 'omitnan');
                if sil > bestSil
                    bestSil = sil; bestIdx = idx0; bestK = K;
                end
            catch
            end
        end
        if isempty(bestIdx)
            warning('kmeans failed.'); return;
        end
        clustIdx = bestIdx;

    case 'gmm'
        opts = statset('MaxIter', 2000, 'Display', 'off');
        bestBIC = inf; gmBest = [];
        for K = Kmin:min(Kmax, max(2,N))
            try
                gm = fitgmdist(X, K, 'RegularizationValue', 1e-6, 'Options', opts, 'Replicates', 10);
                if gm.BIC < bestBIC
                    bestBIC = gm.BIC; gmBest = gm; bestK = K;
                end
            catch
            end
        end
        if isempty(gmBest)
            warning('GMM failed.'); return;
        end
        clustIdx = cluster(gmBest, X);

    otherwise
        error('CLUST_METHOD must be ''kmeans'' or ''gmm''.');
end

% Re-label clusters in ascending mean metric (so cluster 1 = lowest metric)
K = numel(unique(clustIdx));
means = accumarray(clustIdx, X, [K 1], @mean, NaN);
[~, ord] = sort(means, 'ascend');
map = zeros(K,1); 
map(ord) = 1:K;
clustIdx = map(clustIdx);

% FORCE to 2 clusters downstream (keep only clusters 1 and 2)
K = min(2, numel(unique(clustIdx)));
valid = clustIdx <= K;

clustIdx = clustIdx(valid);
X        = X(valid);
i561_2   = i561(valid);
i642_2   = i642(valid);

fprintf('Clustering (%s): using K=%d (forced)\n', lower(CLUST_METHOD), K);
for k = 1:K
    fprintf('  Cluster %d: n=%d, mean metric=%.3f\n', k, sum(clustIdx==k), mean(X(clustIdx==k), 'omitnan'));
end

%% ---------------------------
% 5) EXTRACT TRACES FROM METRIC EXTREMES (HIGH from 561, LOW from 642)
% ---------------------------
% cluster 1 is lowest metric, cluster K is highest metric (after re-labeling)
lowCluster  = 1;
highCluster = K;

idx_low  = find(clustIdx == lowCluster);
idx_high = find(clustIdx == highCluster);

i561_high = i561_2(idx_high);
i642_low  = i642_2(idx_low);

traces561_inMask = traces561(i561_high, :);   % HIGH metric -> 561
traces642_inMask = traces642(i642_low,  :);   % LOW metric  -> 642

%% ---------------------------
% 6) DETREND/SMOOTH + NORMALIZE (requires helper funcs)
% ---------------------------
if DETREND
    traces561_proc = detrend_and_smooth(traces561_inMask, poly_degree, SMOOTHcoeff);
    traces642_proc = detrend_and_smooth(traces642_inMask, poly_degree, SMOOTHcoeff);
else
    traces561_proc = traces561_inMask;
    traces642_proc = traces642_inMask;
end

traces_561 = normalize_traces(traces561_proc, method, baseline_percentile);
traces_642 = normalize_traces(traces642_proc, method, baseline_percentile);

%% ---------------------------
% 7) SELECT ACTIVE TRACES (requires helper func) + SIMPLE PLOTS
% ---------------------------
[traceEARLY, ACTIVESTATUS_EARLY] = filter_traces_by_peak(traces_561, absolute_peak_threshold, SNRthreshold);
[traceLATE,  ACTIVESTATUS_LATE]  = filter_traces_by_peak(traces_642, absolute_peak_threshold, SNRthreshold);

fprintf('Selected %d / %d EARLY traces\n', size(traceEARLY,1), size(traces_561,1));
fprintf('Selected %d / %d LATE traces\n',  size(traceLATE,1),  size(traces_642,1));

% Active ratios
ratio_early = size(traceEARLY,1) / max(1, size(traces_561,1));
ratio_late  = size(traceLATE, 1) / max(1, size(traces_642,1));

figure('Name','Active-cell ratio','Position',[300 280 520 420]);
bar([ratio_early, ratio_late], 0.6);
set(gca, 'XTickLabel', {'EARLY (561)','LATE (642)'}, 'YLim', [0 1]);
ylabel('Active cell ratio'); grid on;
title('Proportion of active cells passing selection');

% Rasters with shared scale based on EARLY
earlyVals = traceEARLY(:); earlyVals = earlyVals(isfinite(earlyVals));
clim = [];
if ~isempty(earlyVals)
    clim = prctile(earlyVals, [1 99.5]);
    if ~all(isfinite(clim)) || diff(clim)<=0, clim = []; end
end

figure('Name','DF/F Rasters (shared scale)','Position',[200 200 1000 420]);

subplot(1,2,1);
imagesc(traceEARLY); colormap gray; colorbar;
xlabel('Time (frames)'); ylabel('ROI'); title('EARLY (561) selected');
if ~isempty(clim), caxis(clim); end

subplot(1,2,2);
imagesc(traceLATE); colormap gray; colorbar;
xlabel('Time (frames)'); ylabel('ROI'); title('LATE (642) selected');
if ~isempty(clim), caxis(clim); end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% useful fucntions
% ---- Helper to detrend+smooth a matrix of traces (rows = ROIs)
function out = detrend_and_smooth(traces, poly_deg, smooth_c)
    if isempty(traces), out = traces; return; end
    T = size(traces,2);
    t = 1:T;
    out = zeros(size(traces));
    for i = 1:size(traces,1)
        y = traces(i,:);
        if poly_deg>0
            p = polyfit(t, y, poly_deg);
            tr = polyval(p, t);
            y = y - tr + mean(tr);       % remove trend, keep mean level
        end
        out(i,:) = smooth(y, smooth_c);   % smooth (moving average-like)
    end
end

% ---- Normalize (DF/F or Z-score)
function Z = normalize_traces(X, modeStr, pct)
    if isempty(X), Z = X; return; end
    Z = zeros(size(X));
    switch lower(modeStr)
        case 'dff'
            for i=1:size(X,1)
                b = prctile(X(i,:), pct);
                if b==0, b = eps; end
                Z(i,:) = (X(i,:) - b) / b;
            end
        case 'zscore'
            for i=1:size(X,1)
                mu = mean(X(i,:)); sg = std(X(i,:));
                if sg==0, sg = eps; end
                Z(i,:) = (X(i,:) - mu) / sg;
            end
        otherwise
            error('Unknown normalization method: %s', modeStr);
    end
end




%--- Fallback helper if not already defined
%if ~exist('filter_traces_by_peak','file')
    function [outTraces,ACTIVESTATUS] = filter_traces_by_peak(traces, abs_thr, snr_thr)
        if isempty(traces), outTraces = traces; return; end
        outIdx = false(size(traces,1),1);
        for i = 1:size(traces,1)
            t = traces(i,:) - median(traces(i,:));
            noise = std(t(t < prctile(t,50))); if noise==0, noise=eps; end
            hasAbs = max(t) >= abs_thr;
            hasSNR = (max(t)/noise) >= snr_thr;
            outIdx(i) = hasAbs & hasSNR;
        end
        outTraces = traces(outIdx,:);
        ACTIVESTATUS=outIdx;
    end

